import "../css/Styles.css";
function Cabecalho() {
  return (
    <div className="superior">
      <h1 className="titulo">Gerenciar Clientes</h1>
    </div>
  );
}
export default Cabecalho;
