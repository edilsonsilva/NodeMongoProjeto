import "../css/Styles.css";
export default function Rodape() {
  return (
    <div className="rodape">
      <p>Todos os direitos reservados &copy;</p>
    </div>
  );
}
