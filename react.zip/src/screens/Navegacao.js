export default function Navegacao() {
  return (
    <div>
      <nav>
        <ul>
          <li>
            <a href="listar">Listar</a>
          </li>
          <li>
            <a href="cadastrar">Cadastrar</a>
          </li>
        </ul>
      </nav>
    </div>
  );
}
